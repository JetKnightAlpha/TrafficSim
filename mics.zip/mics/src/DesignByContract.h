//============================================================================
// Name        : DesignByContract.h
// Author      : Serge Demeyer, modified by Kasper Engelen
// Version     :
// Copyright   : Project Software Engineering - BA1 Informatica - Serge Demeyer - University of Antwerp
// Description : Declarations for design by contract in C++
//============================================================================

#include <assert.h>
#include <iostream>
#include <cstdlib>
#include <functional>

// Global error handler function pointer
extern std::function<void(const std::string&, const char*, int)> g_errorHandler;

// Default error handler that exits
inline void defaultErrorHandler(const std::string& message, const char* file, int line) {
    std::cerr << "REQUIRE Violation: " << message << " in " << file << ":" << line << std::endl;
    std::exit(1);
}

#define REQUIRE(assertion, what) \
        if (!(assertion)) { \
            g_errorHandler(what, __FILE__, __LINE__); \
        }

#define ENSURE(assertion, what) \
        if (!(assertion)) { \
            g_errorHandler(what, __FILE__, __LINE__); \
        }