Write-Host "Compiling tests..." -ForegroundColor Green

# Compile the test executable
try {
    g++ -std=c++17 -I../src -I../tinyxml -I../gtest/include -L../gtest/lib -lgtest -lgtest_main -lpthread ../src/*.cpp ../tinyxml/*.cpp tests.cpp -o test_runner.exe
    
    if ($LASTEXITCODE -ne 0) {
        Write-Host "Compilation failed!" -ForegroundColor Red
        Read-Host "Press Enter to continue"
        exit 1
    }
} catch {
    Write-Host "g++ not found. Please install a C++ compiler." -ForegroundColor Red
    Read-Host "Press Enter to continue"
    exit 1
}

Write-Host "Running tests..." -ForegroundColor Green
Write-Host ""

# Run the tests
./test_runner.exe

Write-Host ""
Write-Host "Tests completed." -ForegroundColor Green
Read-Host "Press Enter to continue" 